const rootURL = 'http://localhost:8080';

export { rootURL };